%Universidad del Valle de Guatemala
%Jorge Hurtado, Fernando Sandoval, Mario Soto
%Proyecto de Simulacion
%Soluciones de Ecuacion de LaPlace
%Teoria Electromagnetica 1.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% LaPlace en Coordenadas Rectangulares %%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Problema 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PRIMER PROBLEMA INCISO A
1;
function [x,y,z,q,t,phi,efield,p] = poten(a,b,n)
  xp = -a:0.1:a;
  yp = -b:0.1:b;
  [x, y] = meshgrid(xp, yp);
  k = 0;
  Eo = 8.84.*10.^-12;
  z = x;
  for i = 1:n
    h = i*pi/b;
    fun = @(y)(2./(b.*sinh(h.*a))).*atan(y./a).*sin(h.*y);
    Fn = (integral(fun,0,b));
    Pot= Fn.* sinh(h.*x).*sin(h.*y);
    k += Pot;
  endfor
  phi = k;
  efield = gradient(-phi);
  [q,t] = gradient(-phi);
  p = Eo.*divergence(q,t);
endfunction 
a=3;
b=3;
Eo = 8.84.*10.^-12;
% potenciales
figure('Name','Grafica de Potencial de LaPlace en Rectangulares')
title('Grafica de Potencial de LaPlace en Rectangulares');
[x,y,z,q,t,phi,efield,p] = poten(a,b,2);
surf(x,y,phi);
colorbar
xlabel('x'), ylabel('y'), zlabel('Potencial')
grid on

% campos electricos 
figure('Name','Grafica de Campo Electrico de LaPlace en Rectangulares')
title('Grafica de Campo Electrico de LaPlace en Rectangulares');
quiver(q,t);
%quiver3(x,y,z,q,t,efield);
colorbar
xlabel('x'), ylabel('y'), zlabel('Campo Electrico')
grid on
% densidad de carga superficial
figure('Name','Densidad de Carga')
title('Densidad de Carga');
plot(y(1:61),(gradient(phi))(1:61))
xlim([-1 3])
xlabel('Y')
ylabel('Densidad de Carga')
grid on


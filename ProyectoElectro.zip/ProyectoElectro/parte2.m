%% PRIMER PROBLEMA INCISO B
1;
function [x,y,z,q,t,phi,efield,p] = poten(a,b,n)
  xp = -a:0.1:a;
  yp = -b:0.1:b;
  [x, y] = meshgrid(xp, yp);
  k = 0;
  Eo = 8.84.*10.^-12;
  e = 2.71828;
  z = x;
  for i = 1:n
    h = i*pi/b;
    j = i*pi*((a/b) + 1);
    d = i*pi;
    g = i*pi*(a/b);
    fun = @(y)((2.*y.^3)+5).*sin(h.*y);
    Fn = (integral(fun,0,b));
    An = ((e.^g+(-e.^-d))./(b.*sinh(j.*a))).*Fn;
    Bn = ((e.^d+(-e.^-g))./(b.*sinh(j.*a))).*Fn;
    Pot= ((An.*e.^((h.*x)) + Bn.*e.^((-h.*x)./b)).*sin(h.*y));
    k += Pot;
  endfor
  phi = k;
  efield = gradient(-phi);
  [q,t] = gradient(-phi);
  p = Eo.*divergence(q,t);
endfunction 
a=1;
b=1;
figure('Name','Grafica de Potencial de LaPlace en Rectangulares')
title('Grafica de Potencial de LaPlace en Rectangulares');
[x,y,z,q,t,phi,efield,p] = poten(a,b,2);
surf(x,y,phi);
colorbar
xlabel('x'), ylabel('y'), zlabel('Potencial')
grid on

% campos electricos 
figure('Name','Grafica de Campo Electrico de LaPlace en Rectangulares')
title('Grafica de Campo Electrico de LaPlace en Rectangulares');
%quiver(q,t);
quiver3(x,y,z,q,t,efield);
colorbar
xlabel('x'), ylabel('y'), zlabel('Campo Electrico')
grid on
% densidad de carga superficial
figure('Name','Densidad de Carga')
title('Densidad de Carga');
plot(y(1:21),(gradient(phi))(1:21))
xlim([-1 1])
xlabel('Y')
ylabel('Densidad de Carga')
grid on
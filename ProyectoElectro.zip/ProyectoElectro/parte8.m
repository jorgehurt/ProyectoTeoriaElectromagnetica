%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Problema 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Grafica de Potencial de LaPlace en Coordenadas Esfericas
%Declaraci�n de variables
R = 1;
e0=1;
P0=-5;
a=3;
b=6;
k=2; 
%Creacion de Grafica
[s,theta] = meshgrid(0:0.1:10,0:pi./40:2.*pi);
[s,phie] = meshgrid(0:0.1:10,0:pi./80:pi);

Pb=((-b.*k)./(e0)).*(1-(a./s))+((2.*k)./(15.*b.*e0)).*((s.*s)-((a.^5)./(s.^3))).*((3.*(cos(theta).^2))-(1))+((P0.*a)./(s));
Pc=((-b.*k.*(b-a))./(e0.*s))+((2.*k.*((b.^5)-(a.^5)))./(15.*b.*e0)).*(3.*(cos(theta).^2)-1)+((P0.*a)./(s));
Pa=P0;
PotGraf=Pa.*(s<a)+Pb.*(s<=b && s>=a)+Pc.*(s>b);


C = s.*theta;
%%[x,y] = pol2cart(theta,s);
[x,y,z]= sph2cart (phie,theta, s);
E=-gradient(PotGraf);
%Ploteo de Grafica en esfericas
figure('Name','Graficas de Potencial Esfericas de LaPlace en Esfericas Problema 1')
title('Grafica de Potencial Esfericas de LaPlace en Esfericas');
tab1 = ('Potencial' );
ax= axes('title','Potencial');
%%Grafica 1
subplot(2,2,1)
surf(s,theta,PotGraf);
colorbar
xlabel('s'), ylabel('theta'), zlabel('Potencial')
grid on
%%Grafica 2
subplot(2,2,3)
contour(s,theta,PotGraf);
colorbar
xlabel('s'), ylabel('theta Potencial CN'), zlabel('Diferencial de Potencial')
grid on
%%Grafica 3
subplot(1,2,2)
[ds,da]=gradient(-PotGraf);
contour(s,theta, E);
hold on
colorbar
quiver3(s,theta,phie,ds,da,E);
xlabel('s'), ylabel('theta Campo Electrico'), zlabel('phie')
hold off
%Grafica 4
%Densidad de carga superficial
%nuevo Plot de densidad
figure('Name','Densidad de Carga')
title('Densidad de Carga');
plot(y(1:101),(gradient(PotGraf))(1:101))
%xlim([-1 3])
xlabel('Y')
ylabel('Densidad de Carga')
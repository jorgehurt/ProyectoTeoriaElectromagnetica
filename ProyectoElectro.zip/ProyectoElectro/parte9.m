%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% LaPlace en Coordenadas Cilindricas %%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Grafica de Potencial de LaPlace en Coordenadas Cilindricas
%Declaraci�n de variables
R = 2;
e0 = 1;
%Llamada a la grafica general
figure('Name','Grafica de Potencial de LaPlace en Cilindricas')
title('Grafica de Potencial de LaPlace en Cilindricas');
%Creacion de Grafica
[s,theta] = meshgrid(2:0.1:10,0:pi./50:2.*pi);
Z = (-(-e0).*s.*cos(theta).*(((R.*R)./(s.^2))-1));
C = s.*theta;
[x,y] = pol2cart(theta,s);
%Ploteo de Grafica
surf(x,y,Z,C);
colorbar
xlabel('x'), ylabel('y'), zlabel('potencial')
grid on